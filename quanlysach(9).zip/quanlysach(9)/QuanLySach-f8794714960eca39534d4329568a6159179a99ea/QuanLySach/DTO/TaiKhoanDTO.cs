﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class TaiKhoanDTO
    {
        private string _NguoiDung;

        public string NguoiDung
        {
            get
            {
                return _NguoiDung;
            }

            set
            {
                _NguoiDung = value;
            }
        }

        public string MatKhau
        {
            get
            {
                return _MatKhau;
            }

            set
            {
                _MatKhau = value;
            }
        }

       

        private string _MatKhau;

        

    }
}
