﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DTO;
namespace DAO
{
    public class TaiKhoanDAO
    {
        // them sua xoa tai khoan
        public static SqlConnection con;

        public static DataTable LoadDataTK()
        {
            string sTruyvan = "Select * from tblTaikhoan";
            con = DataProvider.KetNoi();
            DataTable dt = DataProvider.LayDataTable(sTruyvan, con);
            DataProvider.DongKetNoi(con);
            return dt;
        }
        
        public static bool ThemTk(TaiKhoanDTO tk)
        {
            try
            {
                string sTruyVan = string.Format("Insert into tblTaikhoan(TenDangNhap,MatKhau) values (N'{0}',N'{1}')", tk.NguoiDung, tk.MatKhau);
                con = DataProvider.KetNoi();
                DataTable dt = DataProvider.LayDataTable(sTruyVan, con);
                DataProvider.DongKetNoi(con);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool SuaTK(TaiKhoanDTO tk)
        {
            try
            {
                con = DataProvider.KetNoi();
                string sTruyVan = string.Format("Update tblTaikhoan set MatKhau = N'{0}' where NguoiDung='{1}'", tk.MatKhau, tk.NguoiDung);
                DataProvider.ThucThiTruyVan(sTruyVan, con);
                DataProvider.DongKetNoi(con);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool XoaTK(TaiKhoanDTO tk)
        {
            try
            {
                con = DataProvider.KetNoi();
                string sTruyVan = string.Format("Delete tblTaikhoan where NguoiDung=N'{0}'", tk.NguoiDung);
                DataProvider.ThucThiTruyVan(sTruyVan, con);
                DataProvider.DongKetNoi(con);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
