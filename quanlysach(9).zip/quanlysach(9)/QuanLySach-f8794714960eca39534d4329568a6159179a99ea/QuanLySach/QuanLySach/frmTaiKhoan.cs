﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DTO;
using DAO;
namespace QuanLySach
{
    public partial class frmTaiKhoan : Form
    {
        public frmTaiKhoan()
        {
            InitializeComponent();
        }

        private void chbHienMatKhau_CheckedChanged(object sender, EventArgs e)
        {
            //txtMatKhau.UseSystemPasswordChar = chbHienMatKhau.Checked ? false : true;
            // txtXacNhanMatKhau.UseSystemPasswordChar = chbHienMatKhau.Checked ? false : true;
            // txtMatKhau.Text = txtMatKhau.UseSystemPasswordChar;
            
        }

        private void btnThemTaiKhoan_Click(object sender, EventArgs e)
        {
            /*
            if (txtMatKhau.Text != txtXacNhanMatKhau.Text)
            {
                MessageBox.Show("Mật khẩu xác nhận không khớp");
            }
            else
            {
                //TaiKhoanDAO.ThemTk(t)

            }*/

        }

        private void frmTaiKhoan_Load(object sender, EventArgs e)
        {

        }
    }
}
