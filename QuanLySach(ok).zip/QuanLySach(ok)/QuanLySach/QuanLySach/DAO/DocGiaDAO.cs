﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO;
using System.Data;
using System.Data.SqlClient;

namespace DAO
{
    public class DocGiaDAO
    {
        public static SqlConnection con;

        public static DataTable LoadDataDocGia()
        {
            string sTruyVan = "Select * from tblDocGia a";
            con = DataProvider.KetNoi();
            DataTable dt = DataProvider.LayDataTable(sTruyVan, con);
            return dt;
        }

        public static bool ThemDocGia(DocGiaDTO DocGia)
        {
            string sTruyVan = string.Format(@"insert into tblDocGia values({0},'{1}', N'{2}', N'{3}', N'{4}', N'{5}', N'{6}')", DocGia.IDThe, DocGia.SDT,
                                                                                                                      DocGia.HoTen, DocGia.Email,
                                                                                                                      DocGia.DiaChi, DocGia.LoaiThe,
                                                                                                                      DocGia.TrangThai);
            con = DataProvider.KetNoi();
            DataProvider.ThucThiTruyVan(sTruyVan, con);
            DataProvider.DongKetNoi(con);
            return true;
        }

        public static bool SuaDocGia(DocGiaDTO DocGia)
        {
            string sTruyVan = string.Format("update tblDocGia set SDT='{0}', HoTen=N'{1}', Email=N'{2}', DiaChi=N'{3}', LoaiThe=N'{4}', TrangThai=N'{5}' where IDThe={6}", DocGia.SDT, DocGia.HoTen,
                                                                                                                                                                    DocGia.Email, DocGia.DiaChi,
                                                                                                                                                                    DocGia.LoaiThe, DocGia.TrangThai,
                                                                                                                                                                    DocGia.IDThe);
            con = DataProvider.KetNoi();
            DataProvider.ThucThiTruyVan(sTruyVan, con);
            DataProvider.DongKetNoi(con);
            return true;
        }

        public static bool XoaDocGia(DocGiaDTO DocGia)
        {
            string sTruyVan = string.Format("delete from tblDocGia where IDThe={0}", DocGia.IDThe);
            con = DataProvider.KetNoi();
            DataProvider.ThucThiTruyVan(sTruyVan, con);
            DataProvider.DongKetNoi(con);

            con = DataProvider.KetNoi();
            string sTruyVan1 = string.Format("delete from tblPhieuTra where IDThe={0}", DocGia.IDThe);
            DataProvider.ThucThiTruyVan(sTruyVan1, con);
            DataProvider.DongKetNoi(con);

            con = DataProvider.KetNoi();
            string sTruyVan2 = string.Format("delete from tblPhieuMuon where IDThe={0}", DocGia.IDThe);
            DataProvider.ThucThiTruyVan(sTruyVan1, con);
            DataProvider.DongKetNoi(con);
            return true;
        }
        public static DataTable ID_DocGiaMax()
        {
            string sTruyVan = string.Format("select Max(IDThe) from tblDocGia");
            con = DataProvider.KetNoi();
            DataTable dt = DataProvider.LayDataTable(sTruyVan, con);
            DataProvider.DongKetNoi(con);
            return dt;
        }
        public static DataTable SearchDocGia(string tim)
        {
            con = DataProvider.KetNoi();           
            string sTruyVan = string.Format("Select * from tblDocGia a where HoTen like N'%" + tim + "%' or DiaChi like N'%" + tim + "%' or Email like '%" + tim + "%' or LoaiThe like N'%" + tim + "%' or TrangThai like N'%" + tim + "%'");
            DataTable dt = DataProvider.LayDataTable(sTruyVan, con);
            DataProvider.DongKetNoi(con);
            return dt;
        }
    }
}
