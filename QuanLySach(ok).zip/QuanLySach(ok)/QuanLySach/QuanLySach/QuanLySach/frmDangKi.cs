﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLySach
{
    public partial class frmDangKi : Form
    {
        QuanLySachEntities db = new QuanLySachEntities();
        public frmDangKi()
        {
            InitializeComponent();

        }

        private void btnTaoTaiKhoan_Click(object sender, EventArgs e)
        {
            tblTaikhoan checktk = db.tblTaikhoans.SingleOrDefault(n => n.TenDangNhap == txtTenDangNhap.Text);
            if(checktk!=null)
            {
                MessageBox.Show("Tài khoản đã tồn tại , mời bạn làm lại");
                return;
            }
            tblTaikhoan tk = new tblTaikhoan();
            tk.IDTaiKhoan = db.tblTaikhoans.Select(n => n.IDTaiKhoan).Max() + 1;
            tk.TenDangNhap = txtTenDangNhap.Text;
            tk.MatKhau = txtMatKhau.Text;
            db.tblTaikhoans.Add(tk);
            db.SaveChanges();
            MessageBox.Show("Tạo tài khoản thành công!");
            this.Close();
        }
    }
}
