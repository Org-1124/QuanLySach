﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLySach
{
    public partial class frmDangNhap : Form
    {
        QuanLySachEntities database = new QuanLySachEntities();
        public frmDangNhap()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            tblTaikhoan tk = database.tblTaikhoans.SingleOrDefault(n => n.TenDangNhap == txtTenDangNhap.Text && n.MatKhau == txtMatKhau.Text);
            if(tk==null)
            {
                MessageBox.Show("Tài khoản hoặc mật khẩu sai mời đăng nhập lại");
                return;
            }
            else
            {
                frmMain f = new frmMain();
                f.Show();
                this.Hide();
            }

        }

    }
}
